import random

r = random.Random()
zahl = r.randint(100)