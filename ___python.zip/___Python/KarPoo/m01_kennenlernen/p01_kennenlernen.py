print("Foo")
