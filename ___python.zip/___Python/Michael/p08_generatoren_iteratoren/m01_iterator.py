l = [2, 3, 5, 7, 11]
for x in l:
    print(x)