from p10_requests import *

print(FOO)
print(math.pi)
