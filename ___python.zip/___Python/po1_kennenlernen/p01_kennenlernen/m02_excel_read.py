import pandas as pd
import xlrd

df = pd.read_excel("O:/___Python/personen.xlsx")
print(df.head())
