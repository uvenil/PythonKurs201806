zahl = input("Zahl?")

zaehler = 1

def primzahl(zahl):
