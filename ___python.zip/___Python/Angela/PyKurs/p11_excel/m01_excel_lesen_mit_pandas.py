import pandas as pd


def open_file(path, sheetname = [0]): # [2], parse_dates=["C"], index_col = 0
    for i in open_file.index:
        print(i)
        print(open_file(path, [i]))
        values = []
        for i in range(1, 3):
            values.append(i)
        print(values)
        i += 1




print(open_file("C:\Angela\Python\Bielefeld_2018\Personen.xlsx"))